void foo(int x) {}

void foo(int y) {}

int main() {
  foo(666);

  return 0;
}
