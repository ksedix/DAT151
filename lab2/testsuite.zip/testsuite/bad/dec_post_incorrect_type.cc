int main () {
  bool x;
  x--;
  return 0;
}
