int main() {
	int x = 1;
	{
		int y;
	}
	int x;
	return 0;
}
