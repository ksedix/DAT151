int main() {
  return 0;
  return 0.0;
}
