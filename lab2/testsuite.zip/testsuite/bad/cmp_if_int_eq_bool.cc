int main () {
	if (3 == true) {} else {}
	return 0;
}
