int main() {
  int x = 0;
  bool x = false;
  return 0;
}
