int main() {
  return 0.0;
  return 0;
}
