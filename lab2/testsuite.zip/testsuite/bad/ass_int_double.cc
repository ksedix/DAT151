// Assigning double to int variable.

int main () {
 int x = 1.0;
 return 0 ;
}