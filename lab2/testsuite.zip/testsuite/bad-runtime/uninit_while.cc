int main() {
  int i = 0;

  while (i != 10) {
    int j;

    if (i == 1)
      j = 0;
    else
      i = 10;

    int k = j;  // Variable j is not initialized here.
  }
}
