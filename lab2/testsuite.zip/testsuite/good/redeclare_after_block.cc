int main () {
  { bool x0 = true ; }
  int x0 = 0 ;
  printInt(1);
  return 0;
}
