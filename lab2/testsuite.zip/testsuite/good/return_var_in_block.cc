int main() {
  {
    int x = 0;
    return x;
  }
}
