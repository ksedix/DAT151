void ret() {
  return printInt(0);
}

int main() {
  return 0;
}
