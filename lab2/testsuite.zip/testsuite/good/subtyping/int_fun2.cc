double have_an_int(double arg0, double arg1) {
  return arg0 / arg1;
}

int main() {
  printDouble(have_an_int(1, 2));
  return 0;
}
