int main () {
	while (3 == 3.1) {}
	return 0;
}
