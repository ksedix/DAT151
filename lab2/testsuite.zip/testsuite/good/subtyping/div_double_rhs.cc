int main() {
  printDouble(1 / 2.0);
  return 0;
}
