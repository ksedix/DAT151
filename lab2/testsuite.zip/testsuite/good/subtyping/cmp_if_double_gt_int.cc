int main () {
	if (5.0 > 3)
		int y;
	else {}
	return 0;
}
