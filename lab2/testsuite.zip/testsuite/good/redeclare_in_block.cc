int main () {
  int x0 = 32 ;
  { bool x0 = true ; }
  printInt(x0);
  return 0 ;
}
