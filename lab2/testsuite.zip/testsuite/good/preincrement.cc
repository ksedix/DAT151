int main() {
  int j = 22;
  int k = 23;
  ++j;
  printInt(j);
  printInt(++k);
  return 0;
}
