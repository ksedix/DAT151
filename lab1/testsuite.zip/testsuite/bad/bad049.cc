void foo(&int x) {

}
