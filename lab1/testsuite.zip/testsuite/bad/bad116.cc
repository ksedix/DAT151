int main((int x) = 1) {
	
}
