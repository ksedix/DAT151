typedef int x = 1;
