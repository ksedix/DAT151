int main (*x) {}
