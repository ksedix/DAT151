using cout::5;

int main () {
	return 0;
}
