typedef foo (2+3);
