int foo() {
	while 1; return 2;
}
