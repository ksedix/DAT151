int main() {
	do { int x = 1; } while (4 == 5) { return 1 }
}
