int main () {
	(2+3) x = 1;
}
