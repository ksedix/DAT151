void foo() {
	vector<> x;
}
