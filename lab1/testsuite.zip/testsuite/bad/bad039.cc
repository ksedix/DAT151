int foo() {
	return 2 +;
}
