int main () {
	typedef (45*std::cout) apa;
}
