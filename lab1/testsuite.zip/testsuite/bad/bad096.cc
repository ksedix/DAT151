typedef int void;
