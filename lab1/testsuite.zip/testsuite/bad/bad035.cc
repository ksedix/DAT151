int foo() {
	for (int i = 0; true; return 2) { }
	return x;
}
