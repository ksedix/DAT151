(2)::foo<int>;
