int foo() {
	if 1; return 2;
}
