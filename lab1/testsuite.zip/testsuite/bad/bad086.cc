using (2+3)::foo;
