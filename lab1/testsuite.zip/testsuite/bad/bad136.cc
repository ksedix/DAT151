int main() {
  const (const int &) & foo = 1;
}
