int foo() {
	for (56; 1; i++) { }
	return x;
}
