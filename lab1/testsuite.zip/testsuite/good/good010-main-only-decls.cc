int main() {
	int x1;
	int x2 = 1;
	int x3 = x2 = 4;
	a::b::c::q apa;
	double x4, x5, x6;
	foo x7, x8, x9, x10;
	time_t t;
}
