typedef int main;

int main() {
  typedef int main;
}
