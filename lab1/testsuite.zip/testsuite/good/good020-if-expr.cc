// Andreas, 2021-04-30, test nesting of if expressions _?_:_ and throw.
int x = 1 ? 0 ? throw throw x && y ? 0<1 : 1<0 : 6 < 7 : 2+3 ? a::b::c -= 4 > 5 : d::e::f += x = y;
