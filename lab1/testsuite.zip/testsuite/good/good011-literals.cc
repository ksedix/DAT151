int main() {
  1;
  1.0;
  "foo";
  "foo" "Bar";
  "foo " "bar" "bazz";
  "'" "\t" "\n" "Hello, world!\n";
  'A';
  '\n';
  '"';
  '\'';
  a::b::cx::qx;
}
