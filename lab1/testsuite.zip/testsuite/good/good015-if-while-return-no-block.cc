int main() {
	if (x1 -= x3) while (a::b::c::qx + 3) return 3;
}
