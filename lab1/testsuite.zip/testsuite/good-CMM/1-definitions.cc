// This test file contains only definitions of functions with parameters
// and exactly one local variable declaration.

int f (int x, double y, bool z) {
  int g;
}

void g (int parameter_1) {
  bool local_Variable_1;
}

bool logicalFunction (bool par1, bool par2) {
  double I_am_an_unused_variable;
}

double zzzZZZ () {
  int i;
}

int main () {
  bool b;
}

/* End-of-file comment. */
