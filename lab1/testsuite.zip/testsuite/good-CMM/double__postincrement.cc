int main() {
  double j = 22.3;
  double k = 23.3;
  j++;
  printDouble(j);
  printDouble(k++);
  return 0;
}
