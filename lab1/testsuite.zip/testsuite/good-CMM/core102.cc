// operator precedence
int main () {
	while (2+5*6/5-(67) > 5) {}
	return 0;
}
