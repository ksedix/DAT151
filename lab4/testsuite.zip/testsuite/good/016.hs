dec n = n - 1 ;
main = print ((\ f -> (\ x -> f x) 19) dec) ;
