main = print (if 1 < 2 then 1 else 0) ;  -- result 1
