main = print ((\x -> x) x);
