main = print (\x -> y);
