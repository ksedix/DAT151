int main() {
  printDouble(1.5 + (1 / 2));
  return 0;
}
