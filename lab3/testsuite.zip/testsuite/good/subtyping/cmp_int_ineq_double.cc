int main() {
  1 != 1.1;
  return 0;
}
